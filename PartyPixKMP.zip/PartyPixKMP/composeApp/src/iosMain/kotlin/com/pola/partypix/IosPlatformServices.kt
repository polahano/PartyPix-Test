package com.pola.partypix

import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import platform.Foundation.NSUserDefaults

private const val IOS_DRAFT_KEY = "partypix_draft"

@Composable
actual fun rememberPlatformServices(
    onPhotosImported: (List<ImportedPhoto>) -> Unit,
): PlatformServices = remember {
    object : PlatformServices {
        override val platformName: String = "iOS"

        override val autoGroupingNote: String =
            "This shared module includes the iOS entry point, but photo import and share handoff still need the host iOS app wiring on macOS/Xcode."

        override fun requestImport() {
            // Host iOS app wiring goes here.
        }

        override fun isOnline(): Boolean = true

        override fun shareBundle(title: String, photoUris: List<String>) {
            // Host iOS app wiring goes here.
        }

        override fun loadDraft(): String? = NSUserDefaults.standardUserDefaults.stringForKey(IOS_DRAFT_KEY)

        override fun saveDraft(raw: String) {
            NSUserDefaults.standardUserDefaults.setObject(raw, forKey = IOS_DRAFT_KEY)
        }
    }
}
