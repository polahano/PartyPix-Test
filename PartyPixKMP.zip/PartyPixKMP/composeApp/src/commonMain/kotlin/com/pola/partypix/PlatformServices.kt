package com.pola.partypix

import androidx.compose.runtime.Composable

interface PlatformServices {
    val platformName: String
    val autoGroupingNote: String

    fun requestImport()
    fun isOnline(): Boolean
    fun shareBundle(title: String, photoUris: List<String>)
    fun loadDraft(): String?
    fun saveDraft(raw: String)
}

@Composable
expect fun rememberPlatformServices(
    onPhotosImported: (List<ImportedPhoto>) -> Unit,
): PlatformServices
