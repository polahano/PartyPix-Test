package com.pola.partypix

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json

class PartyPixStore(
    initialState: DraftState,
    private val services: PlatformServices,
) {
    var state by mutableStateOf(initialState.normalize())
        private set

    fun serialize(): String = json.encodeToString(state)

    fun importPhotos(imported: List<ImportedPhoto>) {
        if (imported.isEmpty()) return

        val mergedPhotos = (state.photos + imported).distinctBy { it.id }
        val reviewBucket = state.buckets.firstOrNull { it.isReviewBucket } ?: defaultReviewBucket()
        val updatedReview = reviewBucket.copy(photoIds = mergedPhotos.map { it.id }.toSet())

        val nonReviewBuckets = state.buckets.filterNot { it.isReviewBucket }
        state = state.copy(
            photos = mergedPhotos,
            buckets = listOf(updatedReview) + nonReviewBuckets,
            selectedBucketId = state.selectedBucketId.ifBlank { updatedReview.id },
            message = "Imported ${imported.size} photos. ${services.autoGroupingNote}",
            lastKnownOnline = services.isOnline(),
        ).normalize()
    }

    fun addBucket() {
        val nextIndex = state.buckets.count { !it.isReviewBucket } + 1
        val newBucket = PersonBucket(
            id = "person-$nextIndex",
            displayName = "Friend $nextIndex",
        )
        state = state.copy(
            buckets = state.buckets + newBucket,
            selectedBucketId = newBucket.id,
            message = "Created a new friend bucket. Open it and toggle the photos that belong to that person.",
        ).normalize()
    }

    fun selectBucket(bucketId: String) {
        state = state.copy(selectedBucketId = bucketId).normalize()
    }

    fun updateBucketName(bucketId: String, value: String) {
        updateBucket(bucketId) { bucket ->
            bucket.copy(displayName = value.ifBlank { bucket.displayName })
        }
    }

    fun updateBucketContact(bucketId: String, value: String) {
        updateBucket(bucketId) { bucket -> bucket.copy(contactHint = value) }
    }

    fun togglePhoto(bucketId: String, photoId: String) {
        val bucket = state.buckets.firstOrNull { it.id == bucketId } ?: return
        if (bucket.isReviewBucket) return

        val nextIds = if (photoId in bucket.photoIds) {
            bucket.photoIds - photoId
        } else {
            bucket.photoIds + photoId
        }

        updateBucket(bucketId) { current -> current.copy(photoIds = nextIds) }
    }

    fun queueBucket(bucketId: String) {
        val bucket = state.buckets.firstOrNull { it.id == bucketId } ?: return
        if (bucket.isReviewBucket) return

        val online = services.isOnline()
        val nextStatus = if (online) DeliveryStatus.ReadyToShare else DeliveryStatus.QueuedOffline
        updateBucket(bucketId) { current -> current.copy(status = nextStatus) }

        state = state.copy(
            lastKnownOnline = online,
            message = if (online) {
                "${bucket.displayName} is ready to share. Open the share sheet when you want to send the photos."
            } else {
                "Offline detected. ${bucket.displayName} was queued locally and will stay ready until you come back online."
            },
        )
    }

    fun refreshConnection() {
        val online = services.isOnline()
        val nextBuckets = state.buckets.map { bucket ->
            if (!bucket.isReviewBucket && bucket.status == DeliveryStatus.QueuedOffline && online) {
                bucket.copy(status = DeliveryStatus.ReadyToShare)
            } else {
                bucket
            }
        }

        state = state.copy(
            buckets = nextBuckets,
            lastKnownOnline = online,
            message = if (online) {
                "Connection is back. Queued buckets were promoted to ready-to-share."
            } else {
                "Still offline. Drafts remain queued locally on this device."
            },
        ).normalize()
    }

    fun openShareSheet(bucketId: String) {
        val bucket = state.buckets.firstOrNull { it.id == bucketId } ?: return
        if (bucket.isReviewBucket) return

        if (bucket.photoIds.isEmpty()) {
            state = state.copy(message = "${bucket.displayName} has no selected photos yet.")
            return
        }

        val online = services.isOnline()
        if (!online) {
            queueBucket(bucketId)
            return
        }

        val photoUris = state.photos
            .filter { it.id in bucket.photoIds }
            .map { it.uri }

        services.shareBundle(bucket.displayName, photoUris)
        updateBucket(bucketId) { current -> current.copy(status = DeliveryStatus.ReadyToShare) }
        state = state.copy(
            lastKnownOnline = true,
            message = "Opened the native share sheet for ${bucket.displayName}. After sending in WhatsApp or Messenger, tap Mark shared.",
        )
    }

    fun markShared(bucketId: String) {
        val bucket = state.buckets.firstOrNull { it.id == bucketId } ?: return
        if (bucket.isReviewBucket) return

        updateBucket(bucketId) { current -> current.copy(status = DeliveryStatus.Shared) }
        state = state.copy(message = "Marked ${bucket.displayName} as shared.")
    }

    private fun updateBucket(bucketId: String, block: (PersonBucket) -> PersonBucket) {
        state = state.copy(
            buckets = state.buckets.map { bucket ->
                if (bucket.id == bucketId) block(bucket) else bucket
            },
        ).normalize()
    }

    private fun DraftState.normalize(): DraftState {
        val review = buckets.firstOrNull { it.isReviewBucket } ?: defaultReviewBucket().copy(photoIds = photos.map { it.id }.toSet())
        val others = buckets.filterNot { it.isReviewBucket }
        val mergedBuckets = listOf(review.copy(photoIds = photos.map { it.id }.toSet())) + others
        val validSelected = mergedBuckets.firstOrNull { it.id == selectedBucketId }?.id ?: mergedBuckets.first().id
        return copy(buckets = mergedBuckets, selectedBucketId = validSelected)
    }

    companion object {
        private val json = Json {
            prettyPrint = true
            ignoreUnknownKeys = true
        }

        fun fromSerialized(raw: String?, services: PlatformServices): PartyPixStore {
            val decoded = raw
                ?.takeIf { it.isNotBlank() }
                ?.let {
                    runCatching { json.decodeFromString(DraftState.serializer(), it) }.getOrNull()
                }
                ?: DraftState(lastKnownOnline = services.isOnline())
            return PartyPixStore(decoded, services)
        }
    }
}
