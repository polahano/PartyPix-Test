package com.pola.partypix

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.weight
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import coil3.compose.AsyncImage

@Composable
fun App() {
    var importedBatch by remember { mutableStateOf<List<ImportedPhoto>>(emptyList()) }
    val services = rememberPlatformServices { importedBatch = it }
    val store = remember(services) { PartyPixStore.fromSerialized(services.loadDraft(), services) }

    LaunchedEffect(importedBatch) {
        if (importedBatch.isNotEmpty()) {
            store.importPhotos(importedBatch)
            importedBatch = emptyList()
        }
    }

    LaunchedEffect(store.state) {
        services.saveDraft(store.serialize())
    }

    MaterialTheme {
        Surface(modifier = Modifier.fillMaxSize()) {
            PartyPixScreen(
                state = store.state,
                platformName = services.platformName,
                autoGroupingNote = services.autoGroupingNote,
                onImport = services::requestImport,
                onAddBucket = store::addBucket,
                onRefreshConnection = store::refreshConnection,
                onSelectBucket = store::selectBucket,
                onRenameBucket = store::updateBucketName,
                onUpdateContact = store::updateBucketContact,
                onTogglePhoto = store::togglePhoto,
                onQueueBucket = store::queueBucket,
                onOpenShareSheet = store::openShareSheet,
                onMarkShared = store::markShared,
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun PartyPixScreen(
    state: DraftState,
    platformName: String,
    autoGroupingNote: String,
    onImport: () -> Unit,
    onAddBucket: () -> Unit,
    onRefreshConnection: () -> Unit,
    onSelectBucket: (String) -> Unit,
    onRenameBucket: (String, String) -> Unit,
    onUpdateContact: (String, String) -> Unit,
    onTogglePhoto: (String, String) -> Unit,
    onQueueBucket: (String) -> Unit,
    onOpenShareSheet: (String) -> Unit,
    onMarkShared: (String) -> Unit,
) {
    val selectedBucket = state.selectedBucketOrNull()
    val scrollState = rememberScrollState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        Text(
            text = "PartyPix KMP",
            style = MaterialTheme.typography.headlineMedium,
            fontWeight = FontWeight.Bold,
        )
        Text(
            text = "Offline-first event photo organizer on $platformName. Import party photos, sort them into friend buckets, queue them while offline, and hand them off to WhatsApp or Messenger when back online.",
            style = MaterialTheme.typography.bodyLarge,
        )

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = onImport) {
                Text("Import photos")
            }
            OutlinedButton(onClick = onAddBucket) {
                Text("Add friend")
            }
            OutlinedButton(onClick = onRefreshConnection) {
                Text("Check connection")
            }
        }

        Card(
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer),
        ) {
            Column(
                modifier = Modifier.fillMaxWidth().padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                Text("Prototype note", fontWeight = FontWeight.SemiBold)
                Text(autoGroupingNote)
                Text(state.message)
                Text(
                    text = when (state.lastKnownOnline) {
                        true -> "Connection status: online"
                        false -> "Connection status: offline"
                        null -> "Connection status: not checked yet"
                    },
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.Medium,
                )
            }
        }

        Text("People buckets", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)

        state.buckets.forEach { bucket ->
            val isSelected = bucket.id == state.selectedBucketId
            BucketCard(
                bucket = bucket,
                selected = isSelected,
                onSelect = { onSelectBucket(bucket.id) },
                onRename = { onRenameBucket(bucket.id, it) },
                onUpdateContact = { onUpdateContact(bucket.id, it) },
                onQueue = { onQueueBucket(bucket.id) },
                onOpenShareSheet = { onOpenShareSheet(bucket.id) },
                onMarkShared = { onMarkShared(bucket.id) },
            )
        }

        Text("Photos", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)

        if (state.photos.isEmpty()) {
            Card {
                Column(
                    modifier = Modifier.fillMaxWidth().padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    Text("No photos imported yet.")
                    Text("Use Import photos to pull a party album into the local review queue.")
                }
            }
        } else if (selectedBucket != null) {
            Card {
                Column(
                    modifier = Modifier.fillMaxWidth().padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    Text(
                        text = if (selectedBucket.isReviewBucket) {
                            "The review queue always contains every imported photo. Open a friend bucket to choose what that person should receive."
                        } else {
                            "Toggle the photos that belong to ${selectedBucket.displayName}."
                        },
                        style = MaterialTheme.typography.bodyLarge,
                    )

                    state.photos.forEach { photo ->
                        val isChecked = photo.id in selectedBucket.photoIds
                        PhotoRow(
                            photo = photo,
                            checked = isChecked,
                            enabled = !selectedBucket.isReviewBucket,
                            onToggle = { onTogglePhoto(selectedBucket.id, photo.id) },
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun BucketCard(
    bucket: PersonBucket,
    selected: Boolean,
    onSelect: () -> Unit,
    onRename: (String) -> Unit,
    onUpdateContact: (String) -> Unit,
    onQueue: () -> Unit,
    onOpenShareSheet: () -> Unit,
    onMarkShared: () -> Unit,
) {
    val borderColor = if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .border(width = 1.dp, color = borderColor, shape = RoundedCornerShape(16.dp))
            .clickable(onClick = onSelect),
    ) {
        Column(
            modifier = Modifier.fillMaxWidth().padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(
                    text = if (bucket.isReviewBucket) "System bucket" else "Friend bucket",
                    fontWeight = FontWeight.SemiBold,
                )
                StatusPill(bucket.status)
            }

            OutlinedTextField(
                value = bucket.displayName,
                onValueChange = onRename,
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                label = { Text("Bucket name") },
                enabled = !bucket.isReviewBucket,
            )

            OutlinedTextField(
                value = bucket.contactHint,
                onValueChange = onUpdateContact,
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                label = { Text("WhatsApp / Messenger hint") },
                enabled = !bucket.isReviewBucket,
            )

            Text("Selected photos: ${bucket.photoIds.size}")

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = onSelect) {
                    Text(if (selected) "Opened" else "Open")
                }
                OutlinedButton(onClick = onQueue, enabled = !bucket.isReviewBucket) {
                    Text("Queue")
                }
                Button(onClick = onOpenShareSheet, enabled = !bucket.isReviewBucket) {
                    Text("Share")
                }
                OutlinedButton(onClick = onMarkShared, enabled = !bucket.isReviewBucket) {
                    Text("Mark shared")
                }
            }
        }
    }
}

@Composable
private fun StatusPill(status: DeliveryStatus) {
    val label = when (status) {
        DeliveryStatus.Draft -> "Draft"
        DeliveryStatus.QueuedOffline -> "Queued offline"
        DeliveryStatus.ReadyToShare -> "Ready to share"
        DeliveryStatus.Shared -> "Shared"
    }

    Surface(
        shape = RoundedCornerShape(999.dp),
        color = MaterialTheme.colorScheme.primaryContainer,
    ) {
        Text(
            text = label,
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
            style = MaterialTheme.typography.labelLarge,
        )
    }
}

@Composable
private fun PhotoRow(
    photo: ImportedPhoto,
    checked: Boolean,
    enabled: Boolean,
    onToggle: () -> Unit,
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant)
            .padding(12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        AsyncImage(
            model = photo.uri,
            contentDescription = photo.label,
            modifier = Modifier
                .size(72.dp)
                .clip(RoundedCornerShape(12.dp)),
            contentScale = ContentScale.Crop,
        )

        Column(modifier = Modifier.weight(1f)) {
            Text(photo.label, fontWeight = FontWeight.Medium)
            Spacer(modifier = Modifier.height(4.dp))
            Text(photo.uri, style = MaterialTheme.typography.bodySmall)
        }

        Checkbox(
            checked = checked,
            onCheckedChange = { onToggle() },
            enabled = enabled,
        )
    }
}
