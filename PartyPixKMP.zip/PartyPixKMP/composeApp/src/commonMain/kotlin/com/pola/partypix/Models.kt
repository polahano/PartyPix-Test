package com.pola.partypix

import kotlinx.serialization.Serializable

@Serializable
data class ImportedPhoto(
    val id: String,
    val uri: String,
    val label: String,
)

@Serializable
enum class DeliveryStatus {
    Draft,
    QueuedOffline,
    ReadyToShare,
    Shared,
}

@Serializable
data class PersonBucket(
    val id: String,
    val displayName: String,
    val contactHint: String = "",
    val photoIds: Set<String> = emptySet(),
    val status: DeliveryStatus = DeliveryStatus.Draft,
    val isReviewBucket: Boolean = false,
)

@Serializable
data class DraftState(
    val photos: List<ImportedPhoto> = emptyList(),
    val buckets: List<PersonBucket> = listOf(defaultReviewBucket()),
    val selectedBucketId: String = defaultReviewBucket().id,
    val message: String = DEFAULT_MESSAGE,
    val lastKnownOnline: Boolean? = null,
) {
    fun selectedBucketOrNull(): PersonBucket? = buckets.firstOrNull { it.id == selectedBucketId }
}

const val DEFAULT_MESSAGE =
    "This prototype ships the offline manual-review flow. Add a friend bucket, pick the photos they should receive, queue them offline, then open the share sheet when back online."

fun defaultReviewBucket() = PersonBucket(
    id = "review",
    displayName = "Review queue",
    isReviewBucket = true,
)
