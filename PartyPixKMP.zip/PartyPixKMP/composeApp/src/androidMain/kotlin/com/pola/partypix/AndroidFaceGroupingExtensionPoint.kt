package com.pola.partypix

/**
 * This file is the intended Android hook for the next milestone:
 * real on-device face grouping.
 *
 * Suggested implementation path:
 * 1. Detect faces with ML Kit from each imported image.
 * 2. Crop face regions locally on-device.
 * 3. Run a face-embedding model locally.
 * 4. Cluster embeddings into candidate people buckets.
 * 5. Feed those suggestions into the shared PartyPixStore.
 *
 * Keep manual review in the flow even after clustering is added.
 */
object AndroidFaceGroupingExtensionPoint
