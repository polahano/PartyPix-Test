package com.pola.partypix

import android.content.ClipData
import android.content.Context
import android.content.Intent
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.provider.OpenableColumns
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.platform.LocalContext

private const val PREFS_NAME = "partypix_prefs"
private const val DRAFT_KEY = "draft_state"

@Composable
actual fun rememberPlatformServices(
    onPhotosImported: (List<ImportedPhoto>) -> Unit,
): PlatformServices {
    val context = LocalContext.current
    val launcher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickMultipleVisualMedia(maxItems = 100),
    ) { uris ->
        val imported = uris.map { uri ->
            context.persistReadPermission(uri)
            context.toImportedPhoto(uri)
        }
        onPhotosImported(imported)
    }

    return remember(context, launcher) {
        object : PlatformServices {
            override val platformName: String = "Android"

            override val autoGroupingNote: String =
                "Automatic face clustering is intentionally left as an extension point in this build. The current prototype focuses on the offline queue + manual review flow, which is the safest MVP before adding face embeddings."

            override fun requestImport() {
                launcher.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
            }

            override fun isOnline(): Boolean = context.isCurrentlyOnline()

            override fun shareBundle(title: String, photoUris: List<String>) {
                if (photoUris.isEmpty()) return

                val uriList = ArrayList(photoUris.map(Uri::parse))
                val intent = Intent(Intent.ACTION_SEND_MULTIPLE).apply {
                    type = "image/*"
                    putParcelableArrayListExtra(Intent.EXTRA_STREAM, uriList)
                    putExtra(Intent.EXTRA_SUBJECT, "$title photos")
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }

                val clip = ClipData.newUri(context.contentResolver, title, uriList.first())
                uriList.drop(1).forEach { clip.addItem(ClipData.Item(it)) }
                intent.clipData = clip

                context.startActivity(Intent.createChooser(intent, "Share $title photos").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            }

            override fun loadDraft(): String? =
                context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).getString(DRAFT_KEY, null)

            override fun saveDraft(raw: String) {
                context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                    .edit()
                    .putString(DRAFT_KEY, raw)
                    .apply()
            }
        }
    }
}

private fun Context.toImportedPhoto(uri: Uri): ImportedPhoto {
    val label = contentResolver.query(
        uri,
        arrayOf(OpenableColumns.DISPLAY_NAME),
        null,
        null,
        null,
    )?.use { cursor ->
        val index = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
        if (index >= 0 && cursor.moveToFirst()) cursor.getString(index) else null
    } ?: uri.lastPathSegment ?: "Photo"

    return ImportedPhoto(
        id = uri.toString(),
        uri = uri.toString(),
        label = label,
    )
}

private fun Context.isCurrentlyOnline(): Boolean {
    val connectivityManager = getSystemService(ConnectivityManager::class.java) ?: return false
    val activeNetwork = connectivityManager.activeNetwork ?: return false
    val capabilities = connectivityManager.getNetworkCapabilities(activeNetwork) ?: return false
    return capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) &&
        capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
}


private fun Context.persistReadPermission(uri: Uri) {
    runCatching {
        contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }
}
