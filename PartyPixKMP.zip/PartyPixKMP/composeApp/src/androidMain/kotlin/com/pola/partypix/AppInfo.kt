package com.pola.partypix

const val AndroidBuildFlavor = "manual-review-mvp"
