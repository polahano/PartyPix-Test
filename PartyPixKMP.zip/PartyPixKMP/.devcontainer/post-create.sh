#!/usr/bin/env bash
set -euo pipefail

ANDROID_SDK_ROOT="${ANDROID_SDK_ROOT:-$HOME/android-sdk}"
GRADLE_VERSION="8.11.1"
GRADLE_HOME="${GRADLE_HOME:-$HOME/.gradle-dist/gradle-$GRADLE_VERSION}"
CMDLINE_TOOLS_URL="https://dl.google.com/android/repository/commandlinetools-linux-14742923_latest.zip"
GRADLE_URL="https://services.gradle.org/distributions/gradle-${GRADLE_VERSION}-bin.zip"

mkdir -p "$ANDROID_SDK_ROOT/cmdline-tools" "$HOME/.android" "$HOME/.gradle-dist"
touch "$HOME/.android/repositories.cfg"

if [ ! -x "$ANDROID_SDK_ROOT/cmdline-tools/latest/bin/sdkmanager" ]; then
  TMP_DIR="$(mktemp -d)"
  curl -fsSL "$CMDLINE_TOOLS_URL" -o "$TMP_DIR/cmdline-tools.zip"
  unzip -q "$TMP_DIR/cmdline-tools.zip" -d "$TMP_DIR/unpacked"
  mkdir -p "$ANDROID_SDK_ROOT/cmdline-tools/latest"
  cp -R "$TMP_DIR/unpacked/cmdline-tools/." "$ANDROID_SDK_ROOT/cmdline-tools/latest/"
  rm -rf "$TMP_DIR"
fi

yes | "$ANDROID_SDK_ROOT/cmdline-tools/latest/bin/sdkmanager" --sdk_root="$ANDROID_SDK_ROOT" --licenses >/dev/null || true
"$ANDROID_SDK_ROOT/cmdline-tools/latest/bin/sdkmanager" --sdk_root="$ANDROID_SDK_ROOT" \
  "platform-tools" \
  "platforms;android-35" \
  "build-tools;35.0.0"

if [ ! -x "$GRADLE_HOME/bin/gradle" ]; then
  TMP_DIR="$(mktemp -d)"
  curl -fsSL "$GRADLE_URL" -o "$TMP_DIR/gradle.zip"
  unzip -q "$TMP_DIR/gradle.zip" -d "$HOME/.gradle-dist"
  rm -rf "$TMP_DIR"
fi

cat > local.properties <<LOCALPROPS
sdk.dir=$ANDROID_SDK_ROOT
LOCALPROPS

echo "PartyPix KMP Codespaces environment is ready."
echo "Use: gradle :composeApp:assembleDebug"
