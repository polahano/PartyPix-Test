# Build Notes

## Online / browser-first option

This project is prepared for GitHub Codespaces and GitHub Actions:

- `.devcontainer/devcontainer.json` bootstraps a browser-based dev environment
- `scripts/setup-codespaces-android.sh` installs Android SDK command-line tools
- `.github/workflows/android-debug-apk.yml` builds a debug APK on GitHub and uploads it as an artifact

## Android requirements

- Java 17
- Android SDK platform 35
- Android build-tools 35.0.0
- Gradle 8.11.1

## iOS limitation

The iOS target remains source-only here and still requires a macOS machine with Xcode.
