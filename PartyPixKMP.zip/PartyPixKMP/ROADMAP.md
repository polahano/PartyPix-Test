# PartyPix KMP Roadmap

## MVP status in this archive

Implemented now:

- offline-first draft storage
- Android photo import via photo picker
- manual per-person photo buckets
- offline queue states
- Android native share sheet handoff
- KMP shared UI and shared state model

## Next milestone: automatic face grouping

### Android path

1. Use ML Kit face detection to locate faces in each imported photo.
2. Crop the detected face regions.
3. Feed those crops into a local face-embedding model.
4. Cluster embeddings to create person suggestions.
5. Pre-fill PartyPix friend buckets from those suggestions.
6. Keep manual review before sharing.

### iOS path

Mirror the same idea with Vision / Core ML or keep automatic clustering Android-first and leave iOS on manual review until the model path is settled.

## Recommended product rollout

### Phase 1

- manual review buckets
- offline queue
- one-tap share handoff

### Phase 2

- on-device face detection and clustering suggestions
- confidence score per bucket
- duplicate / near-duplicate filtering

### Phase 3

- event link sharing
- optional cloud backup
- photographer mode
- batch export to compressed ZIP per person

## Guardrails

- keep all processing local by default
- never auto-send messages without explicit user action
- allow the user to review every bucket before sharing
