# PartyPix KMP

PartyPix KMP is an **offline-first Kotlin Multiplatform prototype** for the product idea you described:

- import event photos from the phone
- sort photos into per-person buckets
- queue shares while offline
- open the native share sheet when the device is online again

## What is implemented

This build ships the **manual-review MVP**:

1. import photos with the Android photo picker
2. keep all imported photos in a local review bucket
3. create a bucket for each friend
4. toggle which photos belong to each friend
5. queue a bucket while offline
6. open the Android share sheet for WhatsApp, Messenger, and other apps once back online
7. persist the draft locally so the event can be resumed later

## What is not implemented yet

This repository does **not** include production-grade automatic face recognition yet.
The hook for that work is documented in:

- `composeApp/src/androidMain/kotlin/com/pola/partypix/AndroidFaceGroupingExtensionPoint.kt`
- `ROADMAP.md`

## Open it online in a browser

This project now includes:

- a lightweight Gradle wrapper bootstrap (`gradlew` + `gradle-wrapper.jar`)
- a GitHub Codespaces config in `.devcontainer/devcontainer.json`
- an Android SDK setup script in `scripts/setup-codespaces-android.sh`
- a GitHub Actions workflow that can build a debug APK and upload it as an artifact

### Browser-only path with GitHub Codespaces

1. Create a new GitHub repository.
2. Upload the contents of this project.
3. On GitHub, create a **Codespace** for the repository.
4. Wait for the post-create step to install the Android command-line tools.
5. In the Codespaces terminal, run:

```bash
bash scripts/build-android-debug.sh
```

Expected APK output:

```text
composeApp/build/outputs/apk/debug/
```

### Browser-only path with GitHub Actions

After you upload the repository to GitHub:

1. Open the **Actions** tab.
2. Run the workflow named **Android Debug APK**.
3. Download the generated artifact named **PartyPix-debug-apk**.

## Local build notes

### Android

You can open the project in IntelliJ IDEA or Android Studio.
If you use the command line instead of Android Studio, first install the Android command-line tools and then run:

```bash
bash scripts/setup-codespaces-android.sh
bash scripts/build-android-debug.sh
```

### iOS

The shared iOS entry point is in:

```text
composeApp/src/iosMain/kotlin/com/pola/partypix/MainViewController.kt
```

You still need a macOS machine with Xcode to package or run the iOS host app.

## Suggested next step

Wire real on-device face clustering into `AndroidFaceGroupingExtensionPoint.kt` using ML Kit for face detection plus a local embedding / clustering layer.
