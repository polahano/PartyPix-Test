#!/usr/bin/env bash
set -euo pipefail

if [ ! -f gradle/wrapper/gradle-wrapper.jar ]; then
  echo "Gradle wrapper JAR is not present in this archive."
  exit 1
fi

if [ ! -f local.properties ] && [ -z "${ANDROID_SDK_ROOT:-}" ] && [ -z "${ANDROID_HOME:-}" ]; then
  echo "Android SDK path is not configured."
  echo "Run: bash scripts/setup-codespaces-android.sh"
  exit 1
fi

sh ./gradlew :composeApp:assembleDebug

echo
echo "APK should be at: composeApp/build/outputs/apk/debug/"
