#!/usr/bin/env bash
set -euo pipefail

ANDROID_SDK_ROOT="${ANDROID_SDK_ROOT:-/workspaces/.android-sdk}"
ANDROID_HOME="$ANDROID_SDK_ROOT"
CMDLINE_TOOLS_ZIP="commandlinetools-linux-14742923_latest.zip"
CMDLINE_TOOLS_URL="https://dl.google.com/android/repository/${CMDLINE_TOOLS_ZIP}"
CMDLINE_TOOLS_DIR="$ANDROID_SDK_ROOT/cmdline-tools"
LATEST_DIR="$CMDLINE_TOOLS_DIR/latest"
REPO_DIR="$(pwd)"

export ANDROID_SDK_ROOT ANDROID_HOME
mkdir -p "$CMDLINE_TOOLS_DIR" "$ANDROID_SDK_ROOT/licenses"

if [ ! -x "$LATEST_DIR/bin/sdkmanager" ]; then
  echo "Installing Android command-line tools..."
  TMP_DIR="$(mktemp -d)"
  trap 'rm -rf "$TMP_DIR"' EXIT
  curl -fsSL "$CMDLINE_TOOLS_URL" -o "$TMP_DIR/$CMDLINE_TOOLS_ZIP"
  unzip -q "$TMP_DIR/$CMDLINE_TOOLS_ZIP" -d "$TMP_DIR/unpacked"
  rm -rf "$LATEST_DIR"
  mkdir -p "$LATEST_DIR"
  cp -R "$TMP_DIR/unpacked/cmdline-tools/." "$LATEST_DIR/"
fi

export PATH="$LATEST_DIR/bin:$ANDROID_SDK_ROOT/platform-tools:$PATH"

yes | sdkmanager --licenses >/dev/null || true
sdkmanager \
  "platform-tools" \
  "platforms;android-35" \
  "build-tools;35.0.0"

cat > "$REPO_DIR/local.properties" <<PROPS
sdk.dir=$ANDROID_SDK_ROOT
PROPS

echo "Android SDK ready at $ANDROID_SDK_ROOT"
echo "You can now run: ./scripts/build-android-debug.sh"
