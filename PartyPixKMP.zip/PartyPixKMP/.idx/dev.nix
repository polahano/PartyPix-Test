{ pkgs, ... }: {
  channel = "stable-24.11";

  packages = [
    pkgs.jdk17
    pkgs.gradle
    pkgs.git
    pkgs.unzip
  ];

  env = {
    JAVA_TOOL_OPTIONS = "-Xmx2g";
  };
}
